# base layer

  * what does a edge or a node represent?
    * a node could be a german "Bahnhof"; or 
    * a collective name of a berth grouping

  * usefullness of layer?
    * path traversel
    * are lines connected?
    * A->B->C: does a train need to reverse direction in B?

